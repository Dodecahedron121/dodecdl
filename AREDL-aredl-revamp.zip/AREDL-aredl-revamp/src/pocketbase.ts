import PocketBase from "pocketbase"

export const pb = new PocketBase("https://api.aredl.net");