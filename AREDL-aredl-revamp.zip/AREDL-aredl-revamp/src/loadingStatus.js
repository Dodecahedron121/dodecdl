export const LoadingStatus = {
    LOADING: 0,
    FINISHED: 1,
    ERROR: 2,
}